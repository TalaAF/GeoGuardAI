INSERT INTO municipalities(id,name,code) VALUES ('00000000-0000-0000-0000-000000000001','Pilot Municipality','PILOT') ON CONFLICT DO NOTHING;
INSERT INTO roles(name) VALUES ('admin'),('inspector'),('planner'),('gis_legal'),('drone_operator') ON CONFLICT DO NOTHING;
