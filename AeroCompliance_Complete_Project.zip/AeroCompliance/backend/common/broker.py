import json,pika
from .config import settings
class Broker:
    def publish(self, queue:str, message:dict):
        c=pika.BlockingConnection(pika.URLParameters(settings.rabbitmq_url)); ch=c.channel(); ch.queue_declare(queue=queue,durable=True)
        ch.basic_publish('',queue,json.dumps(message).encode(),pika.BasicProperties(delivery_mode=2,content_type='application/json')); c.close()
    def consume(self,queue,handler):
        c=pika.BlockingConnection(pika.URLParameters(settings.rabbitmq_url)); ch=c.channel(); ch.queue_declare(queue=queue,durable=True); ch.basic_qos(prefetch_count=1)
        def cb(ch,method,props,body):
            try: handler(json.loads(body)); ch.basic_ack(method.delivery_tag)
            except Exception: ch.basic_nack(method.delivery_tag,requeue=False); raise
        ch.basic_consume(queue,cb); ch.start_consuming()
