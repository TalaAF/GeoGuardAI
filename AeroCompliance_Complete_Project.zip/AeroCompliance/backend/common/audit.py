import hashlib,hmac,json,datetime
from .config import settings

def evidence_hash(data:bytes)->str: return hashlib.sha256(data).hexdigest()
def tamper_tag(payload:dict)->str:
    raw=json.dumps(payload,sort_keys=True,separators=(',',':')).encode()
    return hmac.new(settings.evidence_hmac_key.encode(),raw,hashlib.sha256).hexdigest()
def audit_event(action, actor, entity_type, entity_id, details):
    event={'ts':datetime.datetime.now(datetime.timezone.utc).isoformat(),'action':action,'actor':actor,'entity_type':entity_type,'entity_id':str(entity_id),'details':details}
    event['tamper_tag']=tamper_tag(event); return event
