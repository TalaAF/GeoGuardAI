from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    app_env:str='development'; jwt_secret:str='change-me'; jwt_issuer:str='aerocompliance'; jwt_audience:str='aerocompliance-api'
    database_url:str='postgresql+psycopg://aero:aero@localhost:5432/aerocompliance'
    rabbitmq_url:str='amqp://guest:guest@localhost:5672/'; redis_url:str='redis://localhost:6379/0'
    object_storage_root:str='/tmp/aerocompliance'; evidence_hmac_key:str='change-me'; telemetry_hmac_key:str='change-me'
    cors_origins:str='http://localhost:3000'; model_dir:str='/models'
    model_config=SettingsConfigDict(env_file='.env', extra='ignore')
settings=Settings()
