from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
from fastapi import HTTPException, Depends
from fastapi.security import OAuth2PasswordBearer
from .config import settings
oauth2=OAuth2PasswordBearer(tokenUrl='/api/v1/auth/token')

def create_token(sub:str, role:str, municipality_id:str, minutes:int=60):
    now=datetime.now(timezone.utc)
    return jwt.encode({'sub':sub,'role':role,'municipality_id':municipality_id,'iat':now,'exp':now+timedelta(minutes=minutes),'iss':settings.jwt_issuer,'aud':settings.jwt_audience},settings.jwt_secret,algorithm='HS256')

def current_user(token:str=Depends(oauth2)):
    try: return jwt.decode(token,settings.jwt_secret,algorithms=['HS256'],audience=settings.jwt_audience,issuer=settings.jwt_issuer)
    except JWTError as e: raise HTTPException(401,'Invalid token') from e

def require_roles(*roles):
    def dep(user=Depends(current_user)):
        if user.get('role') not in roles: raise HTTPException(403,'Insufficient role')
        return user
    return dep
