from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from pathlib import Path
import uuid,json,hashlib
from common.config import settings
from common.broker import Broker
app=FastAPI(title='AeroCompliance Ingestion Service'); broker=Broker()
@app.post('/ingest')
async def ingest(file:UploadFile=File(...), metadata:str=Form('{}')):
    try: md=json.loads(metadata)
    except: raise HTTPException(400,'invalid metadata JSON')
    data=await file.read(); cap=str(uuid.uuid4()); root=Path(settings.object_storage_root)/'raw'/cap; root.mkdir(parents=True,exist_ok=True)
    path=root/Path(file.filename or 'capture.bin').name; path.write_bytes(data)
    event={'capture_id':cap,'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),'metadata':md}
    broker.publish('capture.landed',event); return event
