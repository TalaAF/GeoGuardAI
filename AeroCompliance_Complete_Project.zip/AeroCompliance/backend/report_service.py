from fastapi import FastAPI
from pydantic import BaseModel
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from openpyxl import Workbook
from pathlib import Path
import uuid
app=FastAPI(title='Report Service')
class ReportIn(BaseModel): case_id:str; summary:str; measurements:dict={}; rules:list[dict]=[]; audit:list[dict]=[]
@app.post('/report')
def report(r:ReportIn):
    out=Path('/tmp/aeroreports');out.mkdir(exist_ok=True); stem=str(uuid.uuid4()); pdf=out/f'{stem}.pdf'; xlsx=out/f'{stem}.xlsx'
    c=canvas.Canvas(str(pdf),pagesize=A4); c.drawString(50,800,'AeroCompliance — POTENTIAL VIOLATION'); c.drawString(50,780,'Human review required; not a confirmed violation.'); c.drawString(50,750,r.summary[:100]); c.save()
    wb=Workbook();ws=wb.active;ws.append(['case_id','summary']);ws.append([r.case_id,r.summary]);wb.save(xlsx)
    return {'pdf':str(pdf),'excel':str(xlsx)}
