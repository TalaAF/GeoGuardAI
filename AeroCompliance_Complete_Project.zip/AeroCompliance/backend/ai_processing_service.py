from fastapi import FastAPI
from ai_processing.pipeline import AeroCompliancePipeline
app=FastAPI(title='AI Processing Service'); pipeline=AeroCompliancePipeline()
@app.get('/health')
def health(): return {'ok':True,'processing_location':'ground_server'}
