from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
app=FastAPI(title='Compliance Matching Service')
class Rule(BaseModel):
    id:str; municipality_id:str; zone_id:str|None=None; block_id:str|None=None; rule_type:str; value:float; unit:str; human_validated:bool=False
ACTIVE={}
@app.post('/rules')
def create_rule(r:Rule): ACTIVE[r.id]=r.model_dump(); return ACTIVE[r.id]
@app.post('/rules/{rid}/activate')
def activate(rid:str):
    if rid not in ACTIVE: raise HTTPException(404)
    if not ACTIVE[rid]['human_validated']: raise HTTPException(409,'Human legal/GIS validation required before activation')
    ACTIVE[rid]['active']=True; return ACTIVE[rid]
