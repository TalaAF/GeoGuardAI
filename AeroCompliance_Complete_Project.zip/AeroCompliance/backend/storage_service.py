from fastapi import FastAPI
from pathlib import Path
from common.config import settings
import os,time
app=FastAPI(title='Storage Service')
@app.get('/health')
def health(): return {'ok':True,'root':settings.object_storage_root}
@app.post('/tier')
def tier(days:int=30):
    hot=Path(settings.object_storage_root)/'raw'; cold=Path(settings.object_storage_root)/'cold'; cold.mkdir(parents=True,exist_ok=True); moved=0
    if hot.exists():
        for p in hot.rglob('*'):
            if p.is_file() and time.time()-p.stat().st_mtime>days*86400:
                dst=cold/p.relative_to(hot); dst.parent.mkdir(parents=True,exist_ok=True); p.replace(dst); moved+=1
    return {'moved':moved}
