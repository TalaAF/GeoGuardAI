from fastapi import FastAPI,Depends,HTTPException,Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from slowapi import Limiter
from slowapi.util import get_remote_address
from pydantic import BaseModel
from common.config import settings
from common.security import create_token,current_user,require_roles
import uuid,datetime
limiter=Limiter(key_func=get_remote_address)
app=FastAPI(title='AeroCompliance API Gateway',version='1.0.0')
app.add_middleware(CORSMiddleware,allow_origins=settings.cors_origins.split(','),allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
USERS={'inspector':{'password':'change-me','role':'inspector'},'admin':{'password':'change-me','role':'admin'}}; DB={'flights':{},'violations':{},'detections':{},'reports':{}}
@app.post('/api/v1/auth/token')
def token(form:OAuth2PasswordRequestForm=Depends()):
    u=USERS.get(form.username)
    if not u or u['password']!=form.password: raise HTTPException(401,'Bad credentials')
    return {'access_token':create_token(form.username,u['role'],'00000000-0000-0000-0000-000000000001'),'token_type':'bearer'}
class Flight(BaseModel): name:str; municipality_id:str; planned_at:datetime.datetime|None=None
@app.get('/api/v1/flights')
def flights(user=Depends(current_user)): return list(DB['flights'].values())
@app.post('/api/v1/flights')
def create_flight(f:Flight,user=Depends(require_roles('admin','drone_operator'))):
    i=str(uuid.uuid4()); DB['flights'][i]={'id':i,**f.model_dump(),'status':'planned'}; return DB['flights'][i]
@app.get('/api/v1/detections')
def detections(user=Depends(current_user)): return list(DB['detections'].values())
@app.get('/api/v1/violations')
def violations(user=Depends(current_user)): return list(DB['violations'].values())
@app.patch('/api/v1/violations/{vid}/review')
def review(vid:str,decision:str,user=Depends(require_roles('inspector','admin'))):
    if decision not in {'confirm','dismiss','more_info'}: raise HTTPException(400)
    v=DB['violations'].setdefault(vid,{'id':vid,'status':'under_review','label':'potential_violation'})
    v['review_decision']=decision; v['reviewer']=user['sub']; v['status']={'confirm':'confirmed_under_notification','dismiss':'dismissed','more_info':'under_review'}[decision]; return v
@app.get('/api/v1/dashboard')
def dashboard(user=Depends(current_user)): return {'potential_violations':len(DB['violations']),'flights':len(DB['flights']),'mandatory_human_review':True}
@app.get('/api/v1/reports')
def reports(user=Depends(current_user)): return list(DB['reports'].values())
@app.get('/api/v1/admin/health')
def admin_health(user=Depends(require_roles('admin'))): return {'ok':True,'ai_processing':'ground_only','audit':'enabled'}
