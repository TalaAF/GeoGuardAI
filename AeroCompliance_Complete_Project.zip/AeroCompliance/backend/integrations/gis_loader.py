import geopandas as gpd, ezdxf
from shapely.geometry import LineString

def load_vector(path,target_crs=None):
    g=gpd.read_file(path); return g.to_crs(target_crs) if target_crs else g

def load_dxf(path,crs='EPSG:4326'):
    doc=ezdxf.readfile(path); rows=[]
    for e in doc.modelspace().query('LWPOLYLINE'):
        pts=[(p[0],p[1]) for p in e.get_points()]; rows.append({'layer':e.dxf.layer,'geometry':LineString(pts)})
    return gpd.GeoDataFrame(rows,geometry='geometry',crs=crs)
