import httpx
async def flight_feasibility(url,key,lat,lon,thresholds=None):
    thresholds=thresholds or {'wind_mps':8,'visibility_km':5}
    async with httpx.AsyncClient(timeout=10) as c: r=await c.get(url,params={'lat':lat,'lon':lon,'key':key}); r.raise_for_status(); w=r.json()
    ok=w.get('wind_mps',99)<=thresholds['wind_mps'] and w.get('visibility_km',0)>=thresholds['visibility_km'] and w.get('precip_mm',0)==0
    return {'feasible':ok,'weather':w,'thresholds':thresholds}
