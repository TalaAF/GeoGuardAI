import os
from twilio.rest import Client

def send_sms(to,message):
    if not os.getenv('TWILIO_ACCOUNT_SID'): return {'sent':False,'reason':'not_configured'}
    c=Client(os.environ['TWILIO_ACCOUNT_SID'],os.environ['TWILIO_AUTH_TOKEN']); m=c.messages.create(to=to,from_=os.environ['TWILIO_FROM'],body='ADVISORY ONLY — '+message); return {'sent':True,'sid':m.sid}
def build_advisory(road_id,lat,lon,object_type): return f'Potential road obstruction detected on {road_id}: {object_type} at {lat:.6f},{lon:.6f}. Human review/audit requirements remain in force.'
