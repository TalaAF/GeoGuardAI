from __future__ import annotations
import cv2, numpy as np, geopandas as gpd
from pathlib import Path
from shapely.geometry import shape, Polygon
from rasterio.features import shapes
from pyproj import CRS
try:
    from ultralytics import YOLO
except Exception: YOLO=None
try:
    import torch, segmentation_models_pytorch as smp
except Exception: torch=smp=None
from sklearn.ensemble import HistGradientBoostingClassifier

CLASS_MAP={0:'background',1:'building',2:'tree',3:'road',4:'water',5:'agricultural'}
class AeroCompliancePipeline:
    def __init__(self, yolo_weights='yolov8n.pt', segmentation_weights=None):
        self.yolo=YOLO(yolo_weights) if YOLO else None
        self.segmenter=None
        if smp:
            self.segmenter=smp.Unet('resnet34',encoder_weights=None,classes=6,activation=None)
            if segmentation_weights and Path(segmentation_weights).exists(): self.segmenter.load_state_dict(torch.load(segmentation_weights,map_location='cpu'))
            self.segmenter.eval()
        self.scorer=HistGradientBoostingClassifier(max_iter=100,random_state=42)
    def generate_orthomosaic(self, images):
        imgs=[cv2.imread(str(x)) if not isinstance(x,np.ndarray) else x for x in images]
        imgs=[x for x in imgs if x is not None]
        if not imgs: raise ValueError('no images')
        if len(imgs)==1: return imgs[0]
        stitcher=cv2.Stitcher_create(cv2.Stitcher_SCANS); code,pano=stitcher.stitch(imgs)
        if code!=cv2.Stitcher_OK: raise RuntimeError(f'orthomosaic stitch failed: {code}; use survey-grade ODM/OpenDroneMap in production')
        return pano
    def tile(self,img,size=1024,overlap=64):
        h,w=img.shape[:2]; step=size-overlap
        for y in range(0,h,step):
            for x in range(0,w,step): yield x,y,img[y:min(y+size,h),x:min(x+size,w)]
    def detect_objects(self, orthomosaic, conf=.25):
        if self.yolo is None: return []
        out=[]
        for x,y,tile in self.tile(orthomosaic):
            for r in self.yolo.predict(tile,conf=conf,verbose=False):
                for b in r.boxes:
                    xy=b.xyxy[0].cpu().numpy().tolist(); out.append({'bbox':[xy[0]+x,xy[1]+y,xy[2]+x,xy[3]+y],'class_id':int(b.cls[0]),'confidence':float(b.conf[0])})
        return out
    def segment_buildings(self, orthomosaic):
        if self.segmenter is None: raise RuntimeError('segmentation-models-pytorch unavailable')
        import torch
        full=np.zeros(orthomosaic.shape[:2],dtype=np.uint8)
        for x,y,tile in self.tile(orthomosaic,512,32):
            rgb=cv2.cvtColor(cv2.resize(tile,(512,512)),cv2.COLOR_BGR2RGB).astype('float32')/255
            ten=torch.from_numpy(rgb.transpose(2,0,1))[None]
            with torch.no_grad(): pred=self.segmenter(ten).argmax(1)[0].numpy().astype('uint8')
            pred=cv2.resize(pred,(tile.shape[1],tile.shape[0]),interpolation=cv2.INTER_NEAREST)
            full[y:y+tile.shape[0],x:x+tile.shape[1]]=pred
        return full
    def segmentation_to_polygons(self, mask, transform, crs='EPSG:4326'):
        rows=[]
        for geom,val in shapes(mask.astype('int16'),mask=mask>0,transform=transform):
            if int(val)==0: continue
            rows.append({'class_id':int(val),'class_name':CLASS_MAP.get(int(val),'unknown'),'geometry':shape(geom)})
        return gpd.GeoDataFrame(rows,geometry='geometry',crs=crs)
    def extract_measurements(self, segments:gpd.GeoDataFrame, gps_data=None):
        metric=segments.to_crs(segments.estimate_utm_crs()) if not segments.empty and segments.crs and segments.crs.is_geographic else segments
        rows=[]
        for i,r in metric.iterrows(): rows.append({'id':int(i),'class_name':r.class_name,'area_m2':float(r.geometry.area),'perimeter_m':float(r.geometry.length),'centroid_wkt':r.geometry.centroid.wkt})
        return rows
    def estimate_height(self, point_cloud_xyz):
        z=np.asarray(point_cloud_xyz)[:,2]; return float(np.percentile(z,95)-np.percentile(z,5))
    def match_to_gis(self, detections:gpd.GeoDataFrame, parcels:gpd.GeoDataFrame, zones:gpd.GeoDataFrame):
        d=detections.to_crs(parcels.crs); p=gpd.sjoin(d,parcels,how='left',predicate='intersects'); return gpd.sjoin(p,zones,how='left',predicate='intersects',rsuffix='zone')
    def check_compliance(self, buildings, parcels, roads, rules):
        if buildings.empty:return []
        crs=parcels.estimate_utm_crs() if parcels.crs and parcels.crs.is_geographic else parcels.crs
        b=buildings.to_crs(crs); p=parcels.to_crs(crs); r=roads.to_crs(crs)
        road_buffer=r.geometry.buffer(float(rules.get('road_setback_m',3.0))).union_all()
        out=[]
        for idx,row in b.iterrows():
            g=row.geometry; hits=p[p.intersects(g)]
            parcel=hits.iloc[0].geometry if len(hits) else None
            road_enc=g.intersection(road_buffer).area
            outside=g.difference(parcel).area if parcel is not None else g.area
            coverage=(g.area/parcel.area*100) if parcel is not None and parcel.area else None
            reasons=[]
            if road_enc>0: reasons.append('road_setback_encroachment')
            if outside>0.05: reasons.append('parcel_boundary_encroachment')
            if coverage is not None and coverage>float(rules.get('max_coverage_pct',60)): reasons.append('coverage_exceeded')
            out.append({'building_id':str(idx),'status':'potential_violation' if reasons else 'no_flag','reasons':reasons,'road_encroachment_m2':float(road_enc),'outside_parcel_m2':float(outside),'coverage_pct':coverage,'requires_human_review':True})
        return out
    def score_violations(self, results):
        for x in results:
            sev=min(1.0,0.25*len(x['reasons'])+min(x['road_encroachment_m2']/20,0.4)+min(x['outside_parcel_m2']/20,0.35)); x['risk_score']=round(sev,3)
        return results
    def generate_report(self, violations): return {'title':'AeroCompliance Potential Violation Report','disclaimer':'AI-assisted; mandatory human review required. Not a confirmed violation.','items':violations}
    def create_audit_trail(self, report):
        import hashlib,json,datetime
        raw=json.dumps(report,sort_keys=True,default=str).encode(); return {'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256':hashlib.sha256(raw).hexdigest()}
