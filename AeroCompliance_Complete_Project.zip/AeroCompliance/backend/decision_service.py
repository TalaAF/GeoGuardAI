from fastapi import FastAPI
from pydantic import BaseModel
app=FastAPI(title='Decision Support Service')
class Features(BaseModel): detection_confidence:float; measurement_uncertainty:float; historical_match:float; severity:float
@app.post('/score')
def score(f:Features):
    risk=max(0,min(1,.35*f.detection_confidence+.25*(1-f.measurement_uncertainty)+.2*f.historical_match+.2*f.severity))
    return {'status':'potential_violation','risk_score':risk,'requires_human_review':True,'confirmed':False}
