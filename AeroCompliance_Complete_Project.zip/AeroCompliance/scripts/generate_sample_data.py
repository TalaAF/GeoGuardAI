from pathlib import Path
import json,random
from shapely.geometry import mapping,Polygon,LineString
out=Path(__file__).resolve().parents[1]/'sample_data';out.mkdir(exist_ok=True)
def fc(features): return {'type':'FeatureCollection','features':features}
def feat(g,p): return {'type':'Feature','geometry':mapping(g),'properties':p}
parcels=[];buildings=[];pid=1000
for iy in range(5):
 for ix in range(5):
  x=35.195+ix*.001;y=31.945+iy*.001; parcel=Polygon([(x,y),(x+.0008,y),(x+.0008,y+.0008),(x,y+.0008)]); parcels.append(feat(parcel,{'parcel_no':pid,'zone':'R1','block_no':f'B{iy+1}'}));
  off=.00005 if random.random()>.15 else -.00005; b=Polygon([(x+off,y+.00015),(x+.00055,y+.00015),(x+.00055,y+.00055),(x+off,y+.00055)]); buildings.append(feat(b,{'building_id':pid,'synthetic_violation':off<0})); pid+=1
road=LineString([(35.194,31.9448),(35.201,31.9448)])
(out/'parcels.geojson').write_text(json.dumps(fc(parcels)));(out/'buildings.geojson').write_text(json.dumps(fc(buildings)));(out/'roads.geojson').write_text(json.dumps(fc([feat(road,{'road_no':'R-1','is_main':True,'is_sensitive':True})])));(out/'rules.json').write_text(json.dumps({'zone':'R1','road_setback_m':3,'neighbor_setback_m':1,'max_coverage_pct':60,'max_height_m':12,'human_validated':False},indent=2));(out/'capture_metadata.json').write_text(json.dumps({'lat':31.95,'lon':35.20,'altitude_m':80,'rtk_fix':'RTK_FIXED','hacc_m':0.02,'camera_yaw':0,'camera_pitch':-90,'imu':{'roll':0.1,'pitch':0.2,'yaw':0.0}},indent=2));print(out)
