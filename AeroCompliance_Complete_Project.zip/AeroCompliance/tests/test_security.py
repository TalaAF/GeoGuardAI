from backend.common.audit import tamper_tag
from hardware_control.communication import LinkManager
def test_audit_tag_deterministic(): assert tamper_tag({'a':1})==tamper_tag({'a':1})
def test_signed_telemetry():
    m=LinkManager(b'secret'); p=m.signed_packet({'lat':1}); assert m.verify(p)
