from fastapi.testclient import TestClient
from backend.api_gateway import app
c=TestClient(app)
def test_auth_rejects_bad_password(): assert c.post('/api/v1/auth/token',data={'username':'admin','password':'bad'}).status_code==401
