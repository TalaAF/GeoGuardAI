import geopandas as gpd
from shapely.geometry import Polygon,LineString
from backend.ai_processing.pipeline import AeroCompliancePipeline

def test_compliance_flags_road_and_parcel():
    p=AeroCompliancePipeline.__new__(AeroCompliancePipeline)
    buildings=gpd.GeoDataFrame([{'geometry':Polygon([(0,0),(4,0),(4,4),(0,4)])}],crs='EPSG:3857')
    parcels=gpd.GeoDataFrame([{'geometry':Polygon([(0,0),(10,0),(10,10),(0,10)])}],crs='EPSG:3857')
    roads=gpd.GeoDataFrame([{'geometry':LineString([(-2,-1),(12,-1)])}],crs='EPSG:3857')
    r=p.check_compliance(buildings,parcels,roads,{'road_setback_m':3,'max_coverage_pct':60})
    assert r[0]['status']=='potential_violation' and r[0]['requires_human_review'] is True
