from locust import HttpUser,task,between
class User(HttpUser):
    wait_time=between(.1,.5)
    @task
    def dashboard(self): self.client.get('/api/v1/dashboard',headers={'Authorization':'Bearer REPLACE_TEST_TOKEN'})
