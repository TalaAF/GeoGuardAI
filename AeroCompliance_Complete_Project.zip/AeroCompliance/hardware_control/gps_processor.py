from dataclasses import dataclass
from pyproj import Transformer
@dataclass
class RTKFix: lat:float; lon:float; alt:float; hacc_m:float; vacc_m:float; fix_type:str
class GPSProcessor:
    def __init__(self,max_hacc_m=.03): self.max_hacc_m=max_hacc_m
    def apply_correction(self,raw:RTKFix,correction:dict)->RTKFix:
        return RTKFix(raw.lat+correction.get('dlat',0),raw.lon+correction.get('dlon',0),raw.alt+correction.get('dalt',0),min(raw.hacc_m,correction.get('hacc_m',raw.hacc_m)),raw.vacc_m,'RTK_FIXED')
    def validate(self,fix):
        if fix.fix_type!='RTK_FIXED' or fix.hacc_m>self.max_hacc_m: raise ValueError(f'RTK precision insufficient: {fix}')
        return True
    def transform(self,fix,epsg):
        t=Transformer.from_crs('EPSG:4326',f'EPSG:{epsg}',always_xy=True); return t.transform(fix.lon,fix.lat,fix.alt)
