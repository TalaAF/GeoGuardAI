from pathlib import Path
import time,json,hashlib
class DataAcquisition:
    def __init__(self,root='captures'): self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
    def capture_image(self,camera,telemetry):
        ts=time.time_ns(); data=camera.capture_4k(); p=self.root/f'{ts}.jpg'; p.write_bytes(data); meta={'ts_ns':ts,'telemetry':telemetry,'sha256':hashlib.sha256(data).hexdigest()}; p.with_suffix('.json').write_text(json.dumps(meta)); return p,meta
    def capture_audio(self,audio_device,duration=5): return audio_device.record(duration)
    def calibrate(self,sensors): return {s.name:s.calibrate() for s in sensors}
