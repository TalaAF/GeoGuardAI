import math
class FlightPlanner:
    def __init__(self,front_overlap=.8,side_overlap=.7): self.front_overlap=front_overlap; self.side_overlap=side_overlap
    def grid(self,bbox,altitude_m=80,speed_mps=5,footprint_width_m=100):
        minx,miny,maxx,maxy=bbox; spacing=footprint_width_m*(1-self.side_overlap); y=miny; pts=[]; flip=False
        while y<=maxy:
            row=[(minx,y,altitude_m),(maxx,y,altitude_m)]; pts.extend(row[::-1] if flip else row); flip=not flip; y+=spacing
        return pts
    def coverage_area(self,width_m,height_m): return width_m*height_m
    def weather_ok(self,w): return w.get('wind_mps',99)<=8 and w.get('visibility_km',0)>=5 and w.get('precip_mm',99)==0
