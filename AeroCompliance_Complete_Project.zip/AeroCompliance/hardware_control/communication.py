import hashlib,hmac,json,time,zlib,ssl
from dataclasses import dataclass
@dataclass
class Link: name:str; priority:int; healthy:bool=True; rssi:int=-60
class LinkManager:
    def __init__(self,key:bytes,links=None): self.key=key; self.links=links or [Link('wifi',1),Link('5g',2),Link('rf',3)]
    def best(self):
        good=[x for x in self.links if x.healthy and x.rssi>-100]
        if not good: raise ConnectionError('No healthy communication link')
        return sorted(good,key=lambda x:(x.priority,-x.rssi))[0]
    def signed_packet(self,payload:dict):
        raw=json.dumps(payload,sort_keys=True,separators=(',',':')).encode(); sig=hmac.new(self.key,raw,hashlib.sha256).hexdigest(); return zlib.compress(json.dumps({'payload':payload,'sig':sig}).encode())
    def verify(self,packet:bytes):
        obj=json.loads(zlib.decompress(packet)); raw=json.dumps(obj['payload'],sort_keys=True,separators=(',',':')).encode(); return hmac.compare_digest(obj['sig'],hmac.new(self.key,raw,hashlib.sha256).hexdigest())
    def heartbeat(self): return {'ts':time.time(),'link':self.best().name,'rssi':self.best().rssi}
