# AeroCompliance — Drone-Based Compliance & Monitoring Platform

Production-oriented reference implementation derived from the supplied AeroCompliance project specification and GIS segmentation workflow.

> **Governance invariant:** every AI-created finding is a **potential violation** until an authorized municipal human reviewer confirms or dismisses it. AI/legal-rule extraction also requires human validation. No AI inference or compliance processing is performed onboard the drone; aircraft/companion systems only capture, compress, sign and transmit.

## Repository layout
- `colab_notebook/` runnable AI/GIS notebook
- `hardware_control/` MAVLink/DJI-adapter flight, RTK, acquisition and communications layer
- `backend/` FastAPI microservices + shared library
- `frontend/` React + Leaflet dashboard
- `database/` PostGIS schema, views, audit triggers and GIS helpers
- `deployment/` Docker, Kubernetes, Azure DevOps, Grafana
- `tests/` unit/integration/security/model tests
- `docs/` architecture/API/deployment/user guide
- `scripts/` sample-data and operational utilities
- `sample_data/` GeoJSON, rules, synthetic capture metadata

## Quick start
```bash
cp .env.example .env
docker compose up --build
# UI: http://localhost:3000
# API: http://localhost:8080/docs
# RabbitMQ: http://localhost:15672
# Grafana: http://localhost:3001
```

Generate deterministic sample GIS data:
```bash
python scripts/generate_sample_data.py
```

Run tests:
```bash
pytest -q
```

## Hardware warning
The repository includes a fully testable simulator and a MAVLink adapter. DJI Enterprise SDK functions are intentionally isolated behind a vendor bridge because activation, aircraft-specific SDK packages, certificates and regulatory permissions cannot be embedded in source code. Do not fly real aircraft until the adapter is validated in a simulator/test range, geofencing/permit requirements are satisfied, RTH behavior is verified, and RTK accuracy is surveyed against control points.
