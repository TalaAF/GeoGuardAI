# API
Base `/api/v1`.
- `POST /auth/token` OAuth2 password-flow development endpoint; production should federate with OIDC/Entra/Keycloak.
- `GET/POST /flights`
- `GET /detections`
- `GET /violations`
- `PATCH /violations/{id}/review?decision=confirm|dismiss|more_info`
- `GET /reports`
- `GET /dashboard`
- `GET /admin/health`

All protected endpoints require `Authorization: Bearer <JWT>` and municipal scope is included in JWT claims. Production deployments should enforce row-level municipality scoping in repositories and database policies.
