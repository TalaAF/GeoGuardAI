# User Guide
## Dashboard
Filter potential findings by date, zone, block, status and type; select a map marker to inspect evidence and confidence.
## Review workflow
Inspect source imagery, orthomosaic overlay, measurements, matched rule and uncertainty. Choose Confirm, Dismiss or Request More Info. The action, user, timestamp and evidence hash are audited.
## Reports
Generate PDF/Excel/CSV only from reviewed case data; reports clearly distinguish potential AI findings from the municipality's human decision.
## Flight planning
Select an authorized area, grid overlap, altitude and speed. Pre-flight requires RTK fixed precision, battery reserve, weather thresholds, communication health and RTH validation.
## Admin
Manage users/roles, municipality/zone/block numbering, rule versions and human validation, retention and system health.
