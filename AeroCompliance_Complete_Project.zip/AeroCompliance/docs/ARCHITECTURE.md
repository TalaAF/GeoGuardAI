# Architecture

```mermaid
flowchart LR
D[Drone capture + RTK] --> I[Ground ingestion]
I --> O[(Object storage)]
I --> Q[RabbitMQ]
Q --> AI[Ground AI processing]
AI --> GIS[GIS/compliance matching]
GIS --> DS[Decision support: potential violation]
DS --> HR{Human reviewer}
HR -->|confirm/dismiss| DB[(PostGIS + audit)]
DB --> UI[React/Leaflet dashboard]
DB --> API[Municipal API by request]
DS -->|sensitive road advisory| PA[Police alert adapter]
```

### Key invariants
1. Drone/companion computer: capture, compression, telemetry, link management only.
2. AI inference, segmentation, measurement, matching and scoring: ground servers only.
3. All AI findings are `potential_violation`; a human reviewer owns final municipal determination.
4. AI-extracted rules cannot become active until `human_validated=true`.
5. Zero-state baseline distinguishes `OK` and `Violation under treatment` before new monitoring begins.
6. Zone/block numbering is the stable indexing key for rules, dashboards and reports.
7. Road setbacks are metric buffers; sample default is 3 m.
8. Segmentation raster -> vector polygons before spatial compliance operations.

### .NET Core 10 target architecture
The Python services in this reference repository follow the same service boundaries required for .NET Core 10. For a .NET implementation, map each FastAPI app to ASP.NET Core Minimal APIs, use MassTransit/RabbitMQ, Npgsql/NetTopologySuite for PostGIS, OpenTelemetry, and .NET Aspire for local composition. Keep AI inference in Python GPU services exposed over RabbitMQ/HTTP/gRPC, because PyTorch/YOLO/segmentation libraries are native Python workloads.
