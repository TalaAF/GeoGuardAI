# Security controls
- OAuth2/OIDC + JWT and RBAC; municipality-scoped authorization.
- TLS 1.2+ everywhere; mTLS recommended for drone/ground gateways.
- HMAC/digital signature for telemetry; unique drone identity certificates.
- Evidence SHA-256 at ingestion; hash-chain immutable audit table; periodic external anchoring recommended.
- Anti-spoofing: reject GNSS jumps, impossible velocity, stale fixes, non-RTK states and signature failures; corroborate with IMU/GCP/flight controller where available.
- Firmware: signed vendor releases, allow-listed versions, staged update and rollback process.
- Privacy: minimize capture, mask unrelated faces/plates where legally required, role/case scoped access, explicit retention and MOU controls.
- AppSec: Pydantic validation, parameterized SQLAlchemy queries, CSP headers, rate limiting, secret manager, Trivy/Bandit/SAST, regular penetration test.
