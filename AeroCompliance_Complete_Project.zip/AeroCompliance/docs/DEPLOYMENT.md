# Deployment
## Development
`cp .env.example .env && docker compose up --build`

## Production
1. Provision Ubuntu Kubernetes nodes, GPU node pool, managed/external PostgreSQL/PostGIS and RabbitMQ or HA equivalents.
2. Create `aero-secrets` from a secret manager; never commit values.
3. Push versioned API/frontend/AI images.
4. Apply Kubernetes manifests and enable TLS ingress/cert-manager.
5. Place AI workloads on GPU nodes with resource limits and separate queues.
6. Configure object storage PV/S3-compatible backend, retention lifecycle and offsite backups.
7. Connect Prometheus/Grafana and Power BI read-only analytics views.
8. Validate restore procedures, audit-chain verification, RTK/GCP survey accuracy and human-review controls before go-live.

## Backup/restore
- PostgreSQL: daily `pg_dump` + WAL/PITR where supported.
- Object evidence: versioned immutable bucket/snapshot + lifecycle to cold tier.
- Audit logs: append-only database table plus periodic signed export to immutable storage.
